# Sampling Theorem and Aliasing — Signals & Systems

**Student:** Rohitanshu Kharbanda  
**Roll Number:** 202410101150241

## Project overview
This Python simulation demonstrates the Sampling Theorem using a 5 Hz sinusoidal signal. It compares undersampling (6 Hz), Nyquist-rate sampling (10 Hz), and oversampling (40 Hz), illustrates aliasing, and applies finite-record sinc interpolation.

## Requirements
- Python 3.9+
- NumPy
- Matplotlib

## Run locally
```bash
python -m pip install -r requirements.txt
python sampling_aliasing.py
```
The program creates four figures in the `figures/` folder.

## Files
- `sampling_aliasing.py` — complete simulation source code
- `requirements.txt` — Python dependencies
- `report.pdf` — technical report
- `figures/` — generated simulation plots

## GitHub upload
1. Sign in to https://github.com and select **New repository**.
2. Name it `sampling-theorem-aliasing`.
3. Choose **Public** (if permitted by your institution) or **Private**.
4. Create the repository.
5. Upload `sampling_aliasing.py`, `requirements.txt`, `report.pdf`, and the `figures/` folder.
6. Add this README as `README.md`.
7. Commit the files.
8. Copy the repository URL and submit it with the PDF on Google Classroom.

## Important interpretation
The Nyquist criterion requires a sampling frequency strictly greater than twice the highest signal frequency for practical reconstruction with a realizable anti-aliasing filter. At exactly twice the frequency, phase and endpoint conditions can make the sampled sequence ambiguous. This project includes the 10 Hz case as the theoretical Nyquist-rate boundary and 40 Hz as a clearly oversampled case.
